#!/bin/sh

docker push ic-registry.epfl.ch/YOURLAB/YOURUSERNAME/YOURPROJECTNAME